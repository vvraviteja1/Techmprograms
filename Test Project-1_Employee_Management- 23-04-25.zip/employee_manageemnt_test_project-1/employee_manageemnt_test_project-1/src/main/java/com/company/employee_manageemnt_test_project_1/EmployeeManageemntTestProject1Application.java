package com.company.employee_manageemnt_test_project_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManageemntTestProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManageemntTestProject1Application.class, args);
	}

}
