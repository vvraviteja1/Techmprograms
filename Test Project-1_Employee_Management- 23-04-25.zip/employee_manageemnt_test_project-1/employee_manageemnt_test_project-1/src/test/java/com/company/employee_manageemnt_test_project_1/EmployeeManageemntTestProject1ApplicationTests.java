package com.company.employee_manageemnt_test_project_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManageemntTestProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
