export class Medicine {

    id: number;
    drug_name: string;
    stock: string;
}
