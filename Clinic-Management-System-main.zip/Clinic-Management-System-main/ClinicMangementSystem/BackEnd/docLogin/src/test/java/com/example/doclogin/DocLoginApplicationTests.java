package com.example.doclogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
